package selenium_login;

import org.testng.Assert;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class MyWebTest {

  	WebDriver driver;
  	
  @Test
  public void f() {
  	//Setting up the chrome driver exe, the second argument is the location where you have kept the driver in your system
	  System.setProperty("webdriver.chrome.driver",
			  "C:\\Users\\Administrator\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
  	 
  	//Setting the driver to chrome driver
  	  driver = new ChromeDriver();
  	  String url = "C:\\Users\\Administrator\\Downloads\\Testing-page-main\\Testing-page-main\\index.html";
  	  driver.get(url);
  	  //Capturing the title and validating if expected is equal to actual
  	  String expectedTitle = "AppTesting";
  	  String actualTitle = driver.getTitle();
  	  Assert.assertEquals(actualTitle, expectedTitle);
  	  
  	  WebElement loginBtn = driver.findElement(By.className("login-button"));
      System.out.println("Clicking on the login button");
      loginBtn.click();
      System.out.println(driver.getTitle());
      
      
      WebElement username = driver.findElement(By.id("username"));
      WebElement password = driver.findElement(By.id("password"));
      WebElement login = driver.findElement(By.id("login"));
      WebElement loginToHome = driver.findElement(By.id("home"));
//      Actions builder = new Actions(driver);
//      builder.moveToElement(email).perform();

      username.clear();
      System.out.println("Entering the username");
      username.sendKeys("amitkumar01");

      password.clear();
      System.out.println("entering the password");
      password.sendKeys("password@123");

      System.out.println("Clicking login button");
      login.click();

      String title = "Login";

      String actualLoginTitle = driver.getTitle();

      System.out.println("Verifying the page title has started");
      Assert.assertEquals(actualLoginTitle,title);

      System.out.println("The page title has been successfully verified");

      System.out.println("User logged in successfully");
      
//      System.out.println("Going back to home page");
//      loginToHome.click();
      System.out.println(driver.getTitle());

//      WebElement signinBtn = driver.findElement(By.className("signup-button"));
//      System.out.println("Clicking on the signin button");
//      signinBtn.click();
    }
  @BeforeMethod
  public void beforeMethod() {
  	  System.out.println("Starting the browser session");
  }
 
  @AfterMethod
  public void afterMethod() {
  	  System.out.println("Closing the browser session");
  	  driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
//  	  driver.quit();
  }
}

 package selenium_login;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;

public class HomePageTestng {
	  WebDriver driver;
	  @Test
	  public void TitleTest() {
			 //Capturing the title and validating if expected is equal to actual
		     String expectedTitle = "AppTesting";
		     String actualTitle = driver.getTitle();
		     System.out.println("Verifying the page title has started");
		     Assert.assertEquals(actualTitle, expectedTitle);
		     System.out.println("The page title has been successfully verified");
	  }
	  
	  @Test
	  public void LoginButtonTest() {
		    //Testing the login button
	    	WebElement loginBtn = driver.findElement(By.className("login-button"));
	        System.out.println("Clicking on the login button");
	        loginBtn.click();
	        System.out.println(driver.getTitle());
	  }
	  
	  @Test
	  public void SignupButtonTest() {
		    //Testing the sign-up button
	    	WebElement signupBtn = driver.findElement(By.className("signup-button"));
	        System.out.println("Clicking on the signup button");
	        signupBtn.click();
	        System.out.println(driver.getTitle());
	  }
		  
	  
	  @BeforeMethod
	  public void beforeMethod() {
		  System.setProperty("webdriver.chrome.driver",
		  "C:\\Users\\Administrator\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
	      //Setting the driver to chrome driver
		  driver = new ChromeDriver();
		  String url = "C:\\Users\\Administrator\\Downloads\\Testing-page-main\\Testing-page-main/index.html";
		  driver.get(url);
		  driver.manage().window().maximize();
	  	  System.out.println("Starting the browser session");
	  }
	 
	  @AfterMethod
	  public void afterMethod() {
	  	  System.out.println("Closing the browser session");
	  	  driver.quit();
	  }
	}
package selenium_login;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;

public class LoginTestNg {
	WebDriver driver;
	  @Test
	  public void TitleTest() {
			 //Capturing the title and validating if expected is equal to actual
		     String expectedTitle = "Login";
		     String actualTitle = driver.getTitle();
		     System.out.println("Verifying the page title has started");
		     Assert.assertEquals(actualTitle, expectedTitle);
		     System.out.println("The page title has been successfully verified");
	  }
	  
	  @Test
	  public void LoginFormTest() {
		    //Testing the login form
	    	WebElement username = driver.findElement(By.id("username"));
	        WebElement password = driver.findElement(By.id("password"));
	        WebElement login = driver.findElement(By.id("login"));
	        
	        username.clear();
	        System.out.println("Entering the username");
	        username.sendKeys("amitkumar01");

	        password.clear();
	        System.out.println("entering the password");
	        password.sendKeys("password@123");

	        System.out.println("Clicking login button");
	        login.click();

	        System.out.println("User logged in successfully");
	  }
		  
	  @Test
	  public void BackToHomeTest() {
		  WebElement loginToHome = driver.findElement(By.id("home"));
		  System.out.println("Clicking on back to home");
		  loginToHome.click();
	  }
	  
	  @BeforeMethod
	  public void beforeMethod() {
		  System.setProperty("webdriver.chrome.driver",
		  "C:\\Users\\Administrator\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
	      //Setting the driver to chrome driver
		  driver = new ChromeDriver();
		  String url = "C:\\Users\\Administrator\\Downloads\\Testing-page-main\\Testing-page-main/login.html";
		  driver.get(url);
		  driver.manage().window().maximize();
	  	  System.out.println("Starting the browser session");
	  }
	 
	  @AfterMethod
	  public void afterMethod() {
	  	  System.out.println("Closing the browser session");
	  	  driver.quit();
	  }
	}
package selenium_login;

import org.junit.Assert;
//Importing required classes
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

//Main class
public class LoginTest {

	// Main driver method
	public static void main(String[] args) {

		// Path of Chrome driver
		// that will be local directory path passed
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Administrator\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		// URL of the login website that is tested
        String url = "C:\\Users\\Administrator\\Downloads\\Testing-page-main\\Testing-page-main/login.html";
 
        driver.get(url);
        driver.manage().window().maximize();
        
        /////////////////////////////////////   PART A END   ////////////////////////////////////////////////////
 
        //Capturing the title and validating if expected is equal to actual
    	String expectedTitle = "Login";
    	String actualTitle = driver.getTitle();
    	System.out.println("Verifying the page title has started");
    	Assert.assertEquals(actualTitle, expectedTitle);
    	System.out.println("The page title has been successfully verified");
    	
    	//Testing the login form
    	WebElement username = driver.findElement(By.id("username"));
        WebElement password = driver.findElement(By.id("password"));
        WebElement login = driver.findElement(By.id("login"));
        WebElement loginToHome = driver.findElement(By.id("home"));
        
        username.clear();
        System.out.println("Entering the username");
        username.sendKeys("amitkumar01");

        password.clear();
        System.out.println("entering the password");
        password.sendKeys("password@123");

        System.out.println("Clicking login button");
        login.click();

        System.out.println("User logged in successfully");
 
        driver.quit();

	}
}

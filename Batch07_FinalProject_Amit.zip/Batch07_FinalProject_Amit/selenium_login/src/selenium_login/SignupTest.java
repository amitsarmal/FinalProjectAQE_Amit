package selenium_login;

import org.junit.Assert;
//Importing required classes
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.interactions.Actions;

//Main class
public class SignupTest {

	// Main driver method
	public static void main(String[] args) {

		// Path of Chrome driver
		// that will be local directory path passed
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Administrator\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		// URL of the login website that is tested
        String url = "C:\\Users\\Administrator\\Downloads\\Testing-page-main\\Testing-page-main/signup.html";
 
        driver.get(url);
        driver.manage().window().maximize();
        
        /////////////////////////////////////   PART A END   ////////////////////////////////////////////////////
 
        //Capturing the title and validating if expected is equal to actual
    	String expectedTitle = "Sign Up";
    	String actualTitle = driver.getTitle();
    	System.out.println("Verifying the page title has started");
    	Assert.assertEquals(actualTitle, expectedTitle);
    	System.out.println("The page title has been successfully verified");
    	
    	//Testing the Signup form
    	WebElement fname = driver.findElement(By.id("fname"));
    	WebElement lname = driver.findElement(By.id("lname"));
    	WebElement username = driver.findElement(By.id("username"));
    	WebElement email = driver.findElement(By.id("email"));
        WebElement password = driver.findElement(By.id("password"));
        WebElement signup = driver.findElement(By.id("signup"));
        WebElement signupToHome = driver.findElement(By.id("home"));
        
        fname.clear();
        System.out.println("Entering the First Name");
        fname.sendKeys("Amit");
        
        lname.clear();
        System.out.println("Entering the Last Name");
        lname.sendKeys("Kumar");
        
        username.clear();
        System.out.println("Entering the username");
        username.sendKeys("amitkumar01");
        
        email.clear();
        System.out.println("Entering the email");
        email.sendKeys("amit@gmail.com");

        password.clear();
        System.out.println("entering the password");
        password.sendKeys("password@123");

        System.out.println("Clicking Signup button");
        signup.click();

        System.out.println("SignedUp successfully");
 
        driver.quit();

	}
}

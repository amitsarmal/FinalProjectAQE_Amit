package selenium_login;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
//Importing required classes
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

//Main class
public class HomePageTest {

	// Main driver method
	public static void main(String[] args) {

		// Path of Chrome driver
		// that will be local directory path passed
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Administrator\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		// URL of the login website that is tested
        String url = "C:\\Users\\Administrator\\Downloads\\Testing-page-main\\Testing-page-main/index.html";
 
        driver.get(url);
        driver.manage().window().maximize();
        driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
        
        /////////////////////////////////////   PART A END   ////////////////////////////////////////////////////
 
        //Capturing the title and validating if expected is equal to actual
    	String expectedTitle = "AppTesting";
    	String actualTitle = driver.getTitle();
    	System.out.println("Verifying the page title has started");
    	Assert.assertEquals(actualTitle, expectedTitle);
    	System.out.println("The page title has been successfully verified");
    	
    	//Testing the login button
    	WebElement loginBtn = driver.findElement(By.className("login-button"));
        System.out.println("Clicking on the login button");
        loginBtn.click();
        System.out.println(driver.getTitle());
        
        WebElement loginToHome = driver.findElement(By.id("home"));
        System.out.println("Going back to home page");
        loginToHome.click();
        System.out.println(driver.getTitle());
        
        //Testing the sign-up button
    	WebElement signupBtn = driver.findElement(By.className("signup-button"));
        System.out.println("Clicking on the signup button");
        signupBtn.click();
        System.out.println(driver.getTitle());
        
        WebElement signupToHome = driver.findElement(By.id("home"));
        System.out.println("Going back to home page");
        signupToHome.click();
        System.out.println(driver.getTitle());
 
        driver.quit();

	}
}